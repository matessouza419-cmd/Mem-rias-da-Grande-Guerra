# Direção criativa — Independência do Brasil

## Abordagens consideradas

### Tema: Arquivo Noturno
Introdução breve: Uma experiência editorial escura, com roxo imperial, textura de papel e composição assimétrica inspirada em arquivos históricos e cartazes de exposição.
Probabilidade: 0.07

### Tema: Aurora Cívica
Introdução breve: Uma narrativa mais luminosa e institucional, misturando verde, amarelo e roxo em uma linguagem de museu digital contemporâneo.
Probabilidade: 0.04

### Tema: Manifesto Tipográfico
Introdução breve: Um site radicalmente editorial, dominado por tipografia monumental, recortes, linhas de tempo e ritmo de pôster cultural.
Probabilidade: 0.09

## Abordagem escolhida: Arquivo Noturno

### Design Movement
Editorial brutalism refinado, com referências a catálogos de exposição, arquivos históricos e pôsteres culturais contemporâneos.

### Core Principles
- Contraste dramático entre preto carvão, roxo profundo e lilás elétrico.
- Conteúdo histórico em camadas: contexto, tensão, ruptura e legado.
- Assimetria controlada, com marcadores de arquivo, números grandes e linhas de tempo verticais.
- Textura e profundidade discretas para evitar uma interface plana, sem perder legibilidade.

### Color Philosophy
O preto representa o peso do período colonial e a densidade dos documentos. O roxo funciona como uma assinatura contemporânea: associa poder, transição e memória, sem tentar reproduzir literalmente as cores da bandeira. O lilás elétrico é reservado para momentos de ação, destaque e descoberta.

### Layout Paradigm
Uma narrativa longa em fluxo editorial, com hero dividido entre manifesto e arte, uma linha do tempo que alterna eixo e blocos de leitura, e seções de personagens organizadas como fichas de arquivo, não como uma grade uniforme.

### Signature Elements
- Selo circular "1822 / ARQUIVO ABERTO".
- Linha vertical de eventos com marcadores roxos e numeração monoespacial.
- Texturas de papel, ruído sutil e filetes de registro em molduras escuras.

### Interaction Philosophy
As interações devem parecer gestos de consulta a um arquivo: navegação com âncoras, filtros suaves, expansão de detalhes e destaque de verbetes. Nada deve competir com o conteúdo histórico.

### Animation
Entradas curtas de opacidade e deslocamento vertical, com cascatas de 40–60 ms. Hover em cartões revela borda lilás e desloca o conteúdo poucos pixels. O selo gira apenas uma vez ao aparecer. Respeitar `prefers-reduced-motion`.

### Typography System
Títulos em Cormorant Garamond, com grande contraste e itálico pontual para frases-manifesto. Corpo em Space Grotesk, funcional e contemporâneo. Metadados em IBM Plex Mono, sempre em caixa alta e com espaçamento ampliado.

### Brand Essence
Um arquivo digital para entender a Independência do Brasil como processo, conflito e legado — feito para estudantes, curiosos e leitores que querem ir além do grito às margens do Ipiranga.
Personalidade: incisiva, culta, inquieta.

### Brand Voice
As manchetes são curtas, imagéticas e assertivas. CTAs convidam à investigação, não à conversão. Microcopy contextualiza sem infantilizar.

Exemplos:
- "Antes do grito, havia um país em disputa."
- "Abra o arquivo: siga as forças que empurraram 1822."

### Wordmark & Logo
Um monograma abstrato formado por duas hastes verticais interrompidas por uma faixa diagonal, evocando a letra I, uma espada e o gesto de ruptura. O símbolo aparece sem texto, acompanhado do wordmark em Cormorant Garamond.

### Signature Brand Color
Roxo Arquivo — `#8B5CF6`, usado como sinal de descoberta sobre o preto carvão, nunca como preenchimento dominante.
