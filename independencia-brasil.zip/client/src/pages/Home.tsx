// Direção visual: Arquivo Noturno — composição assimétrica, marcadores de arquivo, preto carvão e roxo #8B5CF6.
import { useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  BookOpen,
  ChevronDown,
  Clock3,
  ExternalLink,
  Flag,
  Menu,
  ScrollText,
  X,
} from "lucide-react";

const events = [
  { year: "1808", title: "A corte atravessa o Atlântico", text: "A família real portuguesa chega ao Rio de Janeiro, deslocando o centro do Império e acelerando mudanças econômicas e políticas na colônia." },
  { year: "1815", title: "O Brasil vira Reino", text: "A elevação do Brasil a Reino Unido de Portugal e Algarves altera seu status formal e fortalece as elites locais, mas não elimina tensões." },
  { year: "1820", title: "A Revolução Liberal do Porto", text: "Em Portugal, a revolução exige o retorno de D. João VI e uma constituição. As Cortes também querem recolonizar o Brasil." },
  { year: "09.01.1822", title: "O Dia do Fico", text: "D. Pedro decide permanecer no Brasil: “Se é para o bem de todos e felicidade geral da Nação, estou pronto! Digam ao povo que fico.”" },
  { year: "07.09.1822", title: "A ruptura às margens do Ipiranga", text: "Em São Paulo, D. Pedro declara a separação política de Portugal. O gesto se torna o símbolo mais conhecido da Independência." },
  { year: "1823", title: "A independência é consolidada", text: "Conflitos continuam em diferentes províncias. A adesão não é imediata: Bahia, Maranhão, Pará e outras regiões resistem até 1823." },
];

const people = [
  { name: "D. Pedro I", role: "Príncipe regente", mark: "01", text: "Figura central do processo político de 1822. Sua decisão de permanecer e romper com as Cortes transformou uma crise em projeto de separação." },
  { name: "D. João VI", role: "Rei do Reino Unido", mark: "02", text: "A vinda da corte criou novas instituições no Rio, mas também manteve estruturas de poder que alimentaram a disputa entre centro e províncias." },
  { name: "José Bonifácio", role: "Articulador político", mark: "03", text: "Ministro e conselheiro de D. Pedro, defendeu uma monarquia constitucional capaz de manter a unidade territorial do novo país." },
  { name: "Maria Leopoldina", role: "Regente interina", mark: "04", text: "Como regente durante a ausência de D. Pedro, presidiu o Conselho de Estado que recomendou a ruptura e assinou a decisão de 2 de setembro." },
];

const glossary = [
  ["Cortes", "Parlamento português reunido após a Revolução Liberal do Porto."],
  ["Reino Unido", "Estrutura política criada em 1815, unindo Portugal, Brasil e Algarves sob uma mesma monarquia."],
  ["Constituição", "Conjunto de regras que define poderes, direitos e limites de um Estado."],
  ["Reconhecimento", "Processo diplomático pelo qual outros países aceitam a existência do Brasil independente."],
];

export default function Home() {
  const [openMenu, setOpenMenu] = useState(false);
  const [activeGlossary, setActiveGlossary] = useState(0);
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setOpenMenu(false);
  };

  return (
    <main className="site-shell">
      <header className="topbar">
        <button className="brand" onClick={() => scrollTo("top")} aria-label="Voltar ao início">
          <span className="brand-mark"><span /><i /></span>
          <span className="brand-name">arquivo<br /><strong>1822</strong></span>
        </button>
        <nav className={openMenu ? "nav-links is-open" : "nav-links"} aria-label="Navegação principal">
          <button onClick={() => scrollTo("contexto")}>Contexto</button>
          <button onClick={() => scrollTo("linha-do-tempo")}>Linha do tempo</button>
          <button onClick={() => scrollTo("personagens")}>Personagens</button>
          <button onClick={() => scrollTo("legado")}>Legado</button>
        </nav>
        <button className="menu-toggle" onClick={() => setOpenMenu(!openMenu)} aria-label="Abrir menu">
          {openMenu ? <X size={20} /> : <Menu size={20} />}
        </button>
        <span className="archive-stamp">ARQUIVO ABERTO<br /><b>BR / 1822</b></span>
      </header>

      <section id="top" className="hero-section">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" /> história em disputa · 1808—1824</div>
          <h1>Antes do grito,<br /><em>havia um país</em><br />em disputa.</h1>
          <p className="hero-lede">A Independência do Brasil não aconteceu em um único dia. Foi uma ruptura construída entre revoluções, interesses, guerras e a permanência de uma monarquia.</p>
          <button className="text-link" onClick={() => scrollTo("contexto")}>Abrir o arquivo <ArrowDownRight size={17} /></button>
        </div>
        <div className="hero-art" role="img" aria-label="Paisagem noturna inspirada nos acontecimentos de 1822">
          <div className="hero-art-overlay" />
          <div className="hero-art-caption"><span>01 / 06</span><span>margens do Ipiranga · SP</span></div>
          <div className="hero-seal">1822<div>ARQUIVO<br />ABERTO</div></div>
        </div>
        <div className="hero-side-note"><span>BRASIL</span><span>INDEPENDÊNCIA</span><span>PROCESSO · NÃO EVENTO</span></div>
      </section>

      <section id="contexto" className="context-section section-pad">
        <div className="section-kicker">01 / O cenário</div>
        <div className="section-grid">
          <div>
            <h2>Uma colônia que<br /><em>já não cabia</em><br />no império.</h2>
          </div>
          <div className="context-body">
            <p className="intro-paragraph">Quando a família real portuguesa desembarcou no Rio de Janeiro, em 1808, o Brasil deixou de ser apenas a periferia do império. Portos foram abertos, instituições criadas e a vida política ganhou novos atores.</p>
            <p>Mas a transformação tinha limites. A escravidão continuava estruturando a economia, grande parte da população não participava das decisões e as províncias viviam tensões próprias. A independência foi, ao mesmo tempo, uma mudança de soberania e uma tentativa de preservar hierarquias.</p>
            <div className="fact-strip"><span>01</span><strong>13 anos</strong><small>entre a chegada da corte e o reconhecimento português</small></div>
          </div>
        </div>
      </section>

      <section id="linha-do-tempo" className="timeline-section section-pad">
        <div className="section-kicker">02 / O processo</div>
        <div className="timeline-heading"><h2>Seis momentos<br /><em>de uma ruptura.</em></h2><p>Arraste o olhar pela sequência. Cada data revela uma camada do processo — e também o que ficou fora do retrato oficial.</p></div>
        <div className="timeline-list">
          {events.map((event, i) => <article className="timeline-item" key={event.year}>
            <div className="timeline-marker"><span>{String(i + 1).padStart(2, "0")}</span><i /></div>
            <div className="timeline-year">{event.year}</div>
            <div className="timeline-content"><h3>{event.title}</h3><p>{event.text}</p>{i === 4 && <span className="timeline-note"><Flag size={13} /> símbolo mais conhecido · não o fim da guerra</span>}</div>
          </article>)}
        </div>
      </section>

      <section id="personagens" className="people-section section-pad">
        <div className="section-kicker">03 / Quem moveu a história</div>
        <div className="people-heading"><h2>Rostos, projetos<br /><em>e contradições.</em></h2><p>Uma independência monárquica, articulada por poucos e vivida de formas muito diferentes por todo o território.</p></div>
        <div className="people-list">
          {people.map((person) => <article className="person-card" key={person.name}><span className="person-number">{person.mark}</span><div className="person-top"><span className="person-role">{person.role}</span><ArrowUpRight size={17} /></div><h3>{person.name}</h3><p>{person.text}</p><span className="card-rule" /></article>)}
        </div>
      </section>

      <section className="quote-section">
        <div className="quote-mark">“</div><blockquote>Independência ou morte.</blockquote><p>— A fórmula que entrou para a memória nacional. A história, porém, continuou depois dela.</p>
      </section>

      <section id="legado" className="legacy-section section-pad">
        <div className="section-kicker">04 / Depois do grito</div>
        <div className="legacy-layout"><div><h2>O que mudou.<br /><em>O que permaneceu.</em></h2><p className="intro-paragraph">O Brasil se tornou um país independente sob uma monarquia, preservando a escravidão, a concentração de terras e boa parte das elites que já controlavam o poder.</p><p>A separação de Portugal abriu espaço para um Estado nacional, mas não significou cidadania para todos. Entender 1822 é olhar para a fundação de um país e para as perguntas que ela deixou abertas.</p></div><div className="glossary"><div className="glossary-title"><BookOpen size={16} /> verbetes de arquivo</div>{glossary.map(([term, definition], i) => <button className={activeGlossary === i ? "glossary-item active" : "glossary-item"} key={term} onClick={() => setActiveGlossary(i)}><span>{term}</span><ChevronDown size={15} /></button>)}<div className="glossary-definition">{glossary[activeGlossary][1]}</div></div></div>
      </section>

      <footer className="site-footer"><div className="footer-brand"><span className="brand-mark"><span /><i /></span><span><strong>arquivo 1822</strong><small>uma leitura além do grito</small></span></div><div className="footer-meta"><span>feito para aprender, lembrar e questionar</span><span>© 2026 · conteúdo educacional</span></div><button className="back-top" onClick={() => scrollTo("top")}><ArrowUpRight size={18} /> voltar ao início</button></footer>
    </main>
  );
}
